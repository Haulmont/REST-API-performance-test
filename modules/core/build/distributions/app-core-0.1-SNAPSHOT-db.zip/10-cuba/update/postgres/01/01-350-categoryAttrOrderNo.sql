-- $Id: 01-350-categoryAttrOrderNo.sql 5758 2011-08-26 07:00:25Z gorbunkov $
-- Description:
alter table SYS_CATEGORY_ATTR add ORDER_NO integer;