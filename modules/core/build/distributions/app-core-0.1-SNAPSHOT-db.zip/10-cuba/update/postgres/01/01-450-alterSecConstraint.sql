--$Id: 01-450-alterSecConstraint.sql 13792 2013-10-17 11:10:31Z artamonov $

alter table SEC_CONSTRAINT alter column WHERE_CLAUSE type varchar(1000)^